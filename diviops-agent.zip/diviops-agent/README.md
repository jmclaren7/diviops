# DiviOps Agent

**REST API bridge inside the DiviOps AI harness for WordPress — Divi-native today, WordPress-wide by design.**

The WordPress companion plugin for `@diviops/mcp-server`. Pairs with the MCP server to expose Divi 5 page authoring, SCF management, CPT/post population, data model introspection, and site auditing as `/diviops/v1/*` REST endpoints behind Application Password auth.

Divi is a registered trademark of Elegant Themes, Inc. DiviOps Agent is not affiliated with or endorsed by Elegant Themes.

> **Don't use this plugin standalone** — it's the WordPress side of a two-piece suite; install + configure the [DiviOps MCP Server](../../../diviops-server/) next.

## 1.5.50 candidate release note

- Adds optional reviewed-content checksum guards to module and Theme Builder layout updates. Stale content, including same-length edits, refuses before backup or mutation; omission retains the legacy contract.
- Preserves authorization, serialization, scoped recovery and unrelated module content. This is optimistic compare-before-write, not an atomic lock; later concurrent writes can still race.
- Pair with MCP 1.5.76 and reconnect after supported updates. Existing client and runtime qualification limits remain unchanged.

## 1.5.49 historical release note

- Reports nonempty module updates whose requested values are already stored as no-ops, without another write, cache invalidation or snapshot.
- Reports recovery as restored only when restoration is verified; an unverified restore remains a failed write. Existing permission, validation and recovery safeguards remain unchanged.
- This is a reporting correction. The historical distinct-value persistence discrepancy remains unresolved; no additional native or client qualification is claimed.
- MCP 1.5.75 and the delivered builder/primer artifacts are unchanged. PHP remains 7.4+. This preparation does not establish publication or an installed-site update.

## 1.5.48 historical preparation note

- Adds a First steps dashboard section for connecting an AI client, loading the authoring skills and reviewing a first native Divi page.
- Keeps connection and skill setup in the AI client; the dashboard does not claim an active MCP connection or completed onboarding. Existing permissions and provider version gates are unchanged.
- The accompanying public builder 1.4.14 distribution aligns setup guidance and shared-style authoring instructions. Skill installation remains separate from the WordPress plugin. MCP stays at 1.5.74.
- Prior dashboard browser and native checks passed. Exact 1.5.48 package qualification, remaining client verification and publication are pending.

## 1.5.47 release note

- Adds permission-checked inspection of literal Rank Math title, description,
  canonical and robots storage for one editable page. Missing and empty remain
  distinct; duplicate, oversized or unsupported storage refuses without a
  partial result. Serialized values remain untrusted text, not effective SEO,
  inherited defaults, a write plan, recovery evidence or retry permission.
- Pair with **MCP 1.5.74**, then restart/reconnect the MCP client to refresh the
  `seo_storage_inspect` capability. Existing semantic reads, previews, writes and
  recovery keep their exact-version gates; no automatic fallback or override.
- The merged inspector passed bounded native checks with Rank Math 1.0.280 on
  WordPress 7.1, PHP 8.3.35 and Divi 5.13.1. Exact 1.5.47 package qualification and delivery subsequently passed; other
  versions and environments are not covered by that native result. SCF, TSF, Agent Pro and Visuals are unchanged.

## 1.5.46 historical release note

- Displayed the optional Free companion as **DiviOps Visuals** in the addon card.
- Preserved the installed `diviops-design-library` identity and existing
  capability, permission and recovery behavior. That label change did not
  install or update the companion and did not require an MCP reconnect.

## 1.5.45 release note

- Centralizes exact reviewed Rank Math and SCF version support and reports why a provider is unavailable, distinguishing unreviewed versions from inactive identity or missing APIs/setup.
- Aligns bounded verification evidence for Rank Math 1.0.279/1.0.280 and SCF 6.9.4/6.9.5. These are the existing supported sets; no future-version range or bypass is added.
- Preserves permission, checksum, version-drift and recovery guards. Provider-backed reads and previews remain blocked on unreviewed versions. TSF behavior is unchanged.

## 1.5.44 release note

- Exact-set preset cleanup now accepts present SQL NULL metadata as known-empty evidence without changing stored values. Missing fields, invalid identities, references, defaults, stale checksums and scan limits still refuse.
- Includes source-reviewed support for SCF 6.9.5 and Rank Math 1.0.280 alongside the existing supported versions. Rank Math recovery remains bound to its original provider version; cross-version restore stops for inspection.

No new cleanup permission or automatic deletion is introduced. Review a fresh exact-set preview before applying with its registry checksum.

## 1.5.43 candidate release note

- Adds persistent conditional recovery for supported The SEO Framework title and description edits, preserving existing indexing behavior.
- Adds exact operation-outcome lookup for TSF and Rank Math text changes. Single-page authoring, validation and recovery remain Free; uncertain outcomes and conflicting later edits stop instead of being overwritten.
- Native saves, frontend text, conditional recovery and interruption checks passed for TSF 5.1.4 and Rank Math 1.0.279 in the Classic editor on WordPress 7.1, PHP 8.3 and Divi 5.13.1. Other provider versions/editors and process-death recovery are outside this qualification.

Pair with MCP 1.5.72 for operation correlation and outcome lookup. Pro coordination is optional; the Free safety primitives remain independently usable. Final package qualification and delivery are separate gates.

## 1.5.38 release note

Variable scans now report incompatible legacy non-color IDs, whether they are defined, and their known page/preset references. Scan coverage and truncation are explicit. Existing orphan and unused classifications are unchanged. Native page-usage detection is not proof of successful frontend rendering.

Existing mixed-case or underscore IDs still need reviewed replacement variables and reference updates. No variable is renamed or deleted automatically; zero known references does not establish that deletion is safe.

Pair with MCP 1.5.65. Public builder remains 1.4.11; compatibility floors are unchanged.

## Requirements

- WordPress 6.5+
- Divi 5 theme (5.1.0+)
- PHP 7.4+
- Application Passwords enabled (default since WP 5.6)

## Installation

1. Zip this directory: `cd wp-content/plugins && zip -r diviops-agent.zip diviops-agent/`
2. **WP Admin → Plugins → Add New → Upload Plugin** — upload `diviops-agent.zip` and activate.
3. Create an Application Password under **WP Admin → Users → Profile → Application Passwords**.

If Divi is not active, all endpoints return `503 divi_unavailable`. See [setup-guide.md](../../../docs/setup-guide.md) for the full onboarding walkthrough including MCP server registration.

## Updates

The MCP server updates through npm. Once the Free WordPress plugin is published on WordPress.org, WordPress delivers plugin updates through the normal **Dashboard → Updates** and **Plugins** screens.

For pre-listing test packages or a manual fallback install, replace the plugin ZIP through WordPress admin:

1. Download `diviops-agent.zip` from the public dist repo root.
2. Go to **WP Admin → Plugins → Add New → Upload Plugin**.
3. Upload the new `diviops-agent.zip`.
4. Choose **Replace current with uploaded** when WordPress asks.

Your Application Password and MCP client config stay unchanged across Free plugin updates. Purchased Pro users activate Pro update access separately in **DiviOps → Pro License**.

## WordPress.org readiness metadata

The plugin includes a WordPress.org-format `readme.txt` and a plugin-local `changelog.txt`. The readme keeps the current public release entry; longer plugin-local history belongs in `changelog.txt` as the WordPress.org channel matures.

Current metadata policy:

- `Stable tag` matches the plugin header `Version` (`1.5.49` for this candidate).
- `Requires at least` and `Requires PHP` mirror the main plugin header.
- `Tested up to` is evidence-based for this repo/substrate and should not be raised until the Free plugin is actually tested on that WordPress version.
- External-service/authentication disclosure must mention the separately distributed npm MCP server, WordPress Application Passwords, and the rule that secrets do not belong in issues, examples, screenshots, or repo files.
- Free/Pro copy must keep the Free plugin useful while making clear that Pro is the paid workflow-leverage layer and that not every MCP tool is Free-backed.

The current source candidate is Free 1.5.49 for no-op and recovery-outcome
reporting. The delivered baseline is Free 1.5.48 with MCP 1.5.75.
MCP and the delivered builder/primer artifacts are unchanged.
Historical preparation notes retain their original evidence and scope.
Source acceptance, exact-package qualification and publication are separate
steps; this version bump does not establish publication or a site update.

### Historical source preparation notes

The notes below describe earlier source candidates at their preparation time.
Their candidate and delivered-baseline statements are historical, not current
release status; consult the current candidate and baseline above.

Free 1.5.30 introduced native root group-preset composition for module preset
create/update and inspection through `preset_composition_v1`, with matching MCP
support introduced in 1.5.58. `group_presets` replaces the full root map;
omission preserves links and `{}` clears them. Slot/group buckets and existing
references are checked before writes, including dry-run. Heading warnings ask
for explicit levels according to document hierarchy; typography and warning
detection are unchanged. Public builder 1.4.10 introduced matching heading
guidance. Free 1.5.30 has since been delivered.

Previous source preparation: Free 1.5.29 prepares lowercase generated IDs for new non-color design variables
compatible with Divi's detector. Supplied IDs must match `gvid-[0-9a-z-]+`;
invalid IDs are refused as-is, not sanitized or silently renamed. Existing IDs
and references are untouched, including mixed-case IDs. No permissions,
capabilities or compatibility floors change. Source checks are not package
qualification, runtime acceptance or publication; the delivered baseline is
Free 1.5.28, MCP 1.5.56 and builder companion 1.4.9. Builder content is unchanged.

Free 1.5.28 prepares corrections for explicit-index targeting of canonical
empty native Text modules, preserving existing serialization and write guards.
An empty attribute update remains a no-op. Inspector consumer scans now report
unavailable coverage after failed or missing batches while preserving known
samples; overall coverage remains partial and zero references never establishes
that deletion is safe. No new MCP capability or compatibility floor is added.
Source checks do not qualify the new package or prove an installed-site update.
Package qualification, runtime and publication remain separate decisions.

Free 1.5.27 prepares real preset-deletion previews and guarded exact-ID set
deletion through `preset_delete_exact_v1`, literal native Code content validation,
and correct uncached empty-content reads/readback. Exact-set apply requires the
reviewed registry checksum and fresh bounded reference checks; force cannot
bypass them. Legacy single-ID deletion retains its default-only guard, without
reference checks. This is point-in-time protection, not a transaction or rollback.
MCP 1.5.55 also adds optional process-local, one-use reviewed page-content
references; retention is MCP-side, not a new plugin upload or storage service.
Reconnect after updating to refresh capabilities. These are source candidates,
not evidence of package installation, staging fixes or runtime qualification.

Free 1.5.26 prepares optional bounded `page_get` reads. With MCP 1.5.54,
`bounded:true` returns UTF-8-safe raw content chunks of at most 4096 bytes and
the full-content checksum. Continue using `next_offset` and the initial
`expected_checksum`; on content drift, discard the chunks and restart. The
precise `page_get_bounded_utf8_v1` capability refuses unsupported older plugins
before the MCP server fetches a page. Default reads, authentication, permissions,
writes and global compatibility floors remain unchanged. Each chunk request
still reads and hashes the full upstream content: this is not memory-bounded
streaming, a snapshot service or a universal client-delivery guarantee. Candidate
package validation and publication remain separate from source preparation.

Free 1.5.25 prepares a read-only Design System dashboard for inspecting existing
presets, variables and sampled consumers. Preset inspection exposes direct
variable-reference IDs and explicit partial usage coverage; zero references do
not establish that deletion is safe, and stored settings are not computed styles.
Layout warnings now account for supported preset-provided container settings
while preserving inline precedence and unresolved-reference warnings. No write
behavior or global MCP/Pro compatibility floor changes. Candidate package
validation and publication remain separate from this source preparation.

Free 1.5.24 prepares a small correction to the Setup Guide book icon's vertical
alignment in the DiviOps dashboard on WordPress 7.1. This is a presentation-only
fix; existing behavior and compatibility requirements remain unchanged. No MCP
or Pro update is required for the Free dashboard fix. Candidate package
validation and publication remain separate from this source preparation.

Free 1.5.23 prepares basic authoring for one existing applicable top-level SCF
6.9.4 text field. MCP 1.5.52 exposes its capability-gated REST writer, with
preview enabled by default, exact expected-state checks, field validation and
persisted value/reference readback. Pro and WP-CLI are not required. The writer
does not author Divi bindings/design or field definitions; it supplies no atomic
CAS, SCF snapshot rollback or full native-form equivalence. The prior bounded
local proof used temporary Free 1.5.22/MCP 1.5.51, not these candidate versions.
Candidate package validation and publication remain separate.

Free 1.5.22 prepares clearer Not active labels for unloaded optional add-ons and
read-only snapshot history after the component overview, collapsed by default
with its count visible. It also supplies the internal Free-owned protection
service for reviewed recovery: capture the current layout, verify the recovery
point against the actual after-state and permit at most one bounded recovery
attempt on failure. Basic snapshot inspection and guarded restore remain Free;
direct Free restore behavior is unchanged. No public tool, restore UI, full-site
backup or global MCP/Pro version floor is added. Candidate package validation
and publication remain separate from this source preparation.

Free 1.5.21 refreshed the native WordPress admin dashboard presentation with a
clearer installed-component overview and expandable read-only snapshot metadata.
Existing access and compatibility requirements remain unchanged. Displayed status
does not verify MCP connectivity; snapshots are not full-site backups.

Free 1.5.20 added standard WordPress Posts support alongside Pages through
the existing status endpoint. Mapped edit and applicable publish permissions
remain enforced before dry-run plans and no-op responses. Custom post types
and attachments remain unsupported by this endpoint; scheduling is not expanded.
MCP 1.5.50 clarifies the existing tool description; request shapes and the
capability contract are unchanged. No new MCP or Pro version floor is introduced.

Free 1.5.19 prepares a canonical serialization correction for native module
updates containing HTML-bearing attributes. Strict integrity, backups and
rollback remain unchanged; this fix adds no capability or MCP/Pro version floor.
Source preparation is not publication or qualification of a newly built package.

Free 1.5.18 introduced bounded native staff-detail body evidence,
prerequisite checks and the existing recovery-store bridge. Inspection/preflight
remain Free; applying to one existing isolated target body requires Pro's
`cross_env_staff_body_apply` in addition to Free's `cross_env_staff_body_evidence`
and the existing workflow gates. These are feature-specific checks, not a raised
global minimum MCP or Pro/Free version floor. Restart MCP after supported plugin
updates to refresh the startup capability snapshot. Target records, field
definitions and template assignments are not created or changed. The prior
technical proof is not user visual acceptance or qualification of new packages;
it did not test a Visual Builder save or execute rollback.

Free 1.5.16 adds an optional exact-checksum guard to full-content page updates.
It refuses reviewed-content drift before mutation while preserving the legacy
write contract when the guard is omitted. The precise
`page_update_content_expected_checksum` capability distinguishes enforcement
from older Free versions that only advertise the base writer. The packaged plugin is syntax- and
startup-tested across PHP 7.4, 8.0, 8.1, 8.2, and 8.3 before publication.

### Optional targeted-write checksum binding

`module_update` and `tb_layout_update` accept optional `expected_checksum`:
`sha256:` followed by 64 lowercase hexadecimal characters, hashing the exact
owning post's `post_content` bytes. Read `content_checksum` with
`diviops_page_get`, using the page or Theme Builder layout post ID. A module
checksum is not a checksum of only its selected attributes. The Theme Builder
writer still replaces the full supplied content; it does not merge layouts.

The Agent compares the reviewed checksum to the content used to prepare the
operation, then checks uncached database content before preview/no-op or backup
and mutation. Module apply rechecks after serialization as well. Mismatch or an
unavailable fresh row returns HTTP 409 (`module.content_drift` or
`tb.content_drift`, `mutated:false`) before this handler creates a backup,
writes content, or invalidates caches. Invalid checksum syntax returns HTTP 400.
Successful previews reserve nothing: apply must pass the same checksum and
revalidate it. Module no-ops remain no-ops. Omission retains the legacy contract.

This is an optimistic compare-before-write guarantee, **not an atomic
compare-and-swap, transaction, or shared lock**. A concurrent write after the
last comparison, including during backup/save hooks, can still race. Existing
serialization checks, WordPress readback verification and recovery remain in
place; they do not establish atomicity. Changes by other writers are not covered
by `mutated:false`, which describes this handler's rejected operation.

The precise `module_update_expected_checksum` and
`tb_layout_update_expected_checksum` handshake capabilities advertise enforcement.
MCP refuses a guarded request when its capability is absent, without dispatch or
automatic fallback. Existing permission tiers and object checks are unchanged.
This feature does not establish native qualification.

Before a WordPress.org submission, validate the readme and plugin package:

```bash
git diff --check
php -l wp-content/plugins/diviops-agent/diviops-agent.php
```

Then run the official WordPress.org readme validator against `wp-content/plugins/diviops-agent/readme.txt` and run Plugin Check on the packaged plugin. For WordPress.org submission, use `diviops-agent` as the directory slug/text domain target. If WP-CLI is available in the target environment, the Plugin Check command shape is:

```bash
wp plugin install plugin-check --activate
wp plugin check diviops-agent --categories=plugin_repo
```

For WordPress.org-distributed installs, the Free plugin update channel is the standard WordPress.org plugin update flow. Manual ZIP replacement remains a fallback for pre-listing test packages and environments that intentionally install from the public dist repo.

## Pairing with the MCP server

Communication is via the `/diviops/v1/*` REST namespace, authenticated with Application Passwords. The MCP server reads the plugin's per-tool capability map at startup (the `/handshake` endpoint) and only exposes tools the plugin advertises support for — so you can update the plugin and server independently and unsupported tools fail with a clear `capability_missing` error rather than silent runtime breakage.

After installing the plugin, register the MCP server with Claude Code:

```bash
claude mcp add diviops-mcp \
  --env WP_URL=http://your-site.local \
  --env WP_USER=your-wp-username \
  --env WP_APP_PASSWORD=xxxxXXXXxxxxXXXXxxxxXXXX \
  -- npx -y --package @diviops/mcp-server diviops-mcp
```

For Codex, add the same server to `~/.codex/config.toml`:

```toml
[mcp_servers.diviops-mcp]
command = "npx"
args = ["-y", "--package", "@diviops/mcp-server", "diviops-mcp"]

[mcp_servers.diviops-mcp.env]
WP_URL = "http://your-site.local"
WP_USER = "your-wp-username"
WP_APP_PASSWORD = "xxxxXXXXxxxxXXXXxxxxXXXX"
```

See the [DiviOps MCP Server README](../../../diviops-server/) for full setup and the response contract.

## Capabilities

The plugin advertises 98 capability keys through the handshake (full MCP endpoint reference, 91 always-on tools: [docs/server-reference.md](../../../docs/server-reference.md)):

- **Page building** — Divi page/section/module/canvas CRUD; Theme Builder layouts + templates
- **SCF setup + management** — field group provisioning, sync, export/import
- **CPT + post population** — wp-cli-routed post type registration + bulk post operations
- **Data model reasoning** — module schema introspection, SCF field group inspection, post meta surveys
- **Site auditing** — preset audits, design-token usage scans, orphan detection (presets, variables, dangling references)
- **Hybrid site harmonization** — design token APIs (`variable_*`, `global_color_*`, `global_font_*`) for cross-surface design system management between Divi pages and custom PHP templates

### Add-on module discovery

Module schema introspection (`/schema/modules`, `/schema/module/<name>`) covers core `divi/*` modules and third-party Divi 5 add-on modules. A registered block counts as an add-on module when its namespace is on the allowlist or it declares a Divi module category (`module`, `child-module`, `fullwidth-module`).

The allowlist ships with namespaces for common add-ons (Divi Supreme, Divi Torque, Squad Modules, Divi Pixel, DiviFlash, Divi Plus and others). Extend it in `wp-config.php`:

```php
define( 'DIVIOPS_AGENT_MODULE_NAMESPACES', 'myvendor,othervendor' );
```

or with a filter:

```php
add_filter( 'diviops_agent_module_namespaces', function ( $namespaces ) {
	$namespaces[] = 'myvendor';
	return $namespaces;
} );
```

Disable category-based detection with `add_filter( 'diviops_agent_detect_modules_by_category', '__return_false' );`.

## Authentication & permissions

All endpoints require Application Password authentication (Basic Auth). Three permission tiers:

| Tier | WP Capability | Endpoints |
|------|--------------|-----------|
| **Read** | `edit_posts` | Most GET endpoints, `/render`, `/validate/blocks` |
| **Write** | `edit_pages` | Page creation and content modification |
| **Admin** | `manage_options` | Theme options, preset audit/cleanup/update/delete, library save, variable management, scan-orphans |

If Divi is not active, all endpoints return `503 divi_unavailable`. All write operations automatically clear Divi's `et-cache` to ensure CSS regeneration.

## Upgrade from the previous plugin name

1. Deactivate the old `Divi MCP Agent` plugin.
2. Install or copy `diviops-agent/`.
3. Activate `DiviOps Agent`.
4. Keep your MCP server config pointed at `/wp-json/diviops/v1/`; the REST namespace is unchanged.

## Learn more

- [DiviOps MCP Server README](../../../diviops-server/) — server quick start + response contract
- [setup-guide.md](../../../docs/setup-guide.md) — full onboarding walkthrough
- [server-reference.md](../../../docs/server-reference.md) — full per-tool reference
- [troubleshooting.md](../../../docs/troubleshooting.md) — common errors and resolutions
